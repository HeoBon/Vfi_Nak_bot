
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button

class ClientAddScreen(Screen):
    def on_enter(self):
        self.clear_widgets()
        layout = BoxLayout(orientation='vertical', spacing=10, padding=20)
        layout.add_widget(Label(text="Client Add"))
        layout.add_widget(Button(text="Назад", on_release=lambda x: self.manager.current = 'main_menu'))
        self.add_widget(layout)
