
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button

class MainMenuScreen(Screen):
    def on_enter(self):
        self.clear_widgets()
        layout = BoxLayout(orientation='vertical', spacing=10, padding=20)
        buttons = [
            ("Переглянути клієнтів", 'clients_view'),
            ("Додати клієнта", 'client_add'),
            ("Переглянути товари", 'products_view'),
            ("Масові дії з товарами", 'products_batch'),
            ("Створити накладну", 'invoice_create'),
            ("Аналіз продажів", 'sales_analysis'),
            ("Переглянути історію", 'history_view'),
            ("Вийти", None)
        ]
        for label, screen_name in buttons:
            btn = Button(text=label, size_hint_y=None, height=50)
            if screen_name:
                btn.bind(on_release=lambda inst, scr=screen_name: self.manager.current = scr)
            else:
                btn.bind(on_release=lambda inst: exit())
            layout.add_widget(btn)
        self.add_widget(layout)
