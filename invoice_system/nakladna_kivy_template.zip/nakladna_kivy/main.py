
from kivy.app import App
from kivy.uix.screenmanager import ScreenManager
from screens.main_menu import MainMenuScreen
from screens.clients_view import ClientsViewScreen
from screens.client_add import ClientAddScreen
from screens.products_view import ProductsViewScreen
from screens.products_batch import ProductsBatchScreen
from screens.invoice_create import InvoiceCreateScreen
from screens.sales_analysis import SalesAnalysisScreen
from screens.history_view import HistoryViewScreen

class NakladnaApp(App):
    def build(self):
        sm = ScreenManager()
        sm.add_widget(MainMenuScreen(name='main_menu'))
        sm.add_widget(ClientsViewScreen(name='clients_view'))
        sm.add_widget(ClientAddScreen(name='client_add'))
        sm.add_widget(ProductsViewScreen(name='products_view'))
        sm.add_widget(ProductsBatchScreen(name='products_batch'))
        sm.add_widget(InvoiceCreateScreen(name='invoice_create'))
        sm.add_widget(SalesAnalysisScreen(name='sales_analysis'))
        sm.add_widget(HistoryViewScreen(name='history_view'))
        return sm

if __name__ == '__main__':
    NakladnaApp().run()
