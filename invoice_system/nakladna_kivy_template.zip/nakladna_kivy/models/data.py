
def get_clients():
    return ["Клієнт 1", "Клієнт 2"]

def get_products():
    return ["Товар A", "Товар B"]
